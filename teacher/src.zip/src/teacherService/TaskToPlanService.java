package teacherService;

import empties.TaskToplan;
import teacherDao.TaskToPlanDao;

public class TaskToPlanService {
	private TaskToPlanDao taskToPlanDao;

	public TaskToPlanDao getTaskToPlanDao() {
		return taskToPlanDao;
	}

	public void setTaskToPlanDao(TaskToPlanDao taskToPlanDao) {
		this.taskToPlanDao = taskToPlanDao;
	}

	public int deleteByTaskToPlan(long t_id) {
		// TODO Auto-generated method stub
		int i=taskToPlanDao.deleteByTitle(t_id); 
		i+=taskToPlanDao.deleteByTaskToPlan(t_id);
		return i;
	}

	public int updateByTaskToPlan(TaskToplan model) {
		// TODO Auto-generated method stub
		return taskToPlanDao.updateByTaskToPlan(model);
	}
	
}
