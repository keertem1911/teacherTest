package teacherDao;

import org.mybatis.spring.SqlSessionTemplate;

import comment.BaseDao;

public class StudentToCourseDao extends BaseDao{


}
