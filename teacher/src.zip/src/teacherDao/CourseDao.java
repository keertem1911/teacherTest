package teacherDao;

import org.mybatis.spring.SqlSessionTemplate;

import comment.BaseDao;

public class CourseDao extends BaseDao{
	
	 
}
