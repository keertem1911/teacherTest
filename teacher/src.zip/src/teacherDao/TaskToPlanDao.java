package teacherDao;

import comment.BaseDao;
import empties.TaskToplan;

public class TaskToPlanDao extends BaseDao{

	public int deleteByTaskToPlan(long t_id) {
		// TODO Auto-generated method stub
		return sqlSessionTemplate.delete("tasktoplan.deleteByTaskToPlan",t_id);
	}

	public int updateByTaskToPlan(TaskToplan model) {
		// TODO Auto-generated method stub
		return sqlSessionTemplate.update("tasktoplan.updateByTaskToPlan",model);
	}

	public int deleteByTitle(long t_id) {
		// TODO Auto-generated method stub
		return sqlSessionTemplate.delete("tasktoplan.deleteByTitle",t_id);
	}

}
