package empties;

public class ModelAndTask {

}
